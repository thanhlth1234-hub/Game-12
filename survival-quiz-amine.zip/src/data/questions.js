module.exports = [
  {
    id: 1,
    quota: 50,
    text: "Công thức phân tử tổng quát của amine đơn chức, no, mạch hở là gì?",
    options: { A: "CnH2n+1N", B: "CnH2n+3N", C: "CnH2n-1N", D: "CnH2n+2N" },
    correctAnswer: "B"
  },
  {
    id: 2,
    quota: 45,
    text: "Chất nào sau đây thuộc loại amine bậc hai?",
    options: { A: "Methylamine", B: "Dimethylamine", C: "Trimethylamine", D: "Aniline" },
    correctAnswer: "B"
  },
  {
    id: 3,
    quota: 40,
    text: "Ở điều kiện thường, chất nào sau đây là chất khí, có mùi khai khó chịu, độc và tan nhiều trong nước?",
    options: { A: "Aniline", B: "Ethylamine", C: "Ethanol", D: "Phenol" },
    correctAnswer: "B"
  },
  {
    id: 4,
    quota: 35,
    text: "Dung dịch chất nào sau đây làm quỳ tím chuyển sang màu xanh?",
    options: { A: "Aniline", B: "Methylamine", C: "Phenol", D: "Glucose" },
    correctAnswer: "B"
  },
  {
    id: 5,
    quota: 30,
    text: "Thứ tự sắp xếp lực base tăng dần nào sau đây là đúng?",
    options: {
      A: "C6H5NH2 < NH3 < CH3NH2",
      B: "NH3 < C6H5NH2 < CH3NH2",
      C: "CH3NH2 < NH3 < C6H5NH2",
      D: "C6H5NH2 < CH3NH2 < NH3"
    },
    correctAnswer: "A"
  },
  {
    id: 6,
    quota: 20,
    text: "Hiện tượng xảy ra khi nhỏ nước bromine vào dung dịch aniline là gì?",
    options: {
      A: "Xuất hiện kết tủa trắng",
      B: "Dung dịch chuyển màu xanh lam",
      C: "Sủi bọt khí không màu",
      D: "Xuất hiện kết tủa màu vàng"
    },
    correctAnswer: "A"
  },
  {
    id: 7,
    quota: 10,
    text: "Để rửa sạch ống nghiệm dính aniline sau thí nghiệm, nên dùng dung dịch nào trước tiên?",
    options: { A: "Dung dịch NaOH", B: "Dung dịch HCl", C: "Dung dịch NaCl", D: "Nước vôi trong" },
    correctAnswer: "B"
  },
  {
    id: 8,
    quota: 6,
    text: "Số lượng đồng phân cấu tạo amine có cùng công thức phân tử C3H9N là bao nhiêu?",
    options: { A: "2", B: "3", C: "4", D: "5" },
    correctAnswer: "C"
  },
  {
    id: 9,
    quota: 3,
    text: "Khi cho ethylamine phản ứng với nitrous acid (HNO2) ở nhiệt độ thường, hiện tượng sinh ra là gì?",
    options: {
      A: "Tạo muối diazonium bền",
      B: "Tạo kết tủa vàng",
      C: "Sủi bọt khí nitrogen",
      D: "Không có hiện tượng gì"
    },
    correctAnswer: "C"
  },
  {
    id: 10,
    quota: 1,
    text: "Cho 4,5 gam một amine no, đơn chức, mạch hở X tác dụng vừa đủ với dung dịch HCl thu được 8,15 gam muối. Công thức cấu tạo của X là:",
    options: { A: "CH3NH2", B: "C2H5NH2", C: "C3H7NH2", D: "(CH3)2NH" },
    correctAnswer: "B"
  }
];
