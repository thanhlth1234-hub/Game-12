const questions = require('./data/questions');

class GameManager {
  constructor() {
    this.status = 'LOBBY';
    this.currentQuestionIndex = 0;
    this.questionStartTime = null;
    this.timerInterval = null;
    this.timeRemaining = 30;
    this.players = new Map();
  }

  addPlayer(socketId, nickname) {
    this.players.set(socketId, {
      id: socketId,
      nickname: nickname || `Thí sinh ${this.players.size + 1}`,
      isAlive: true,
      currentAnswer: null,
      responseTimeMs: null,
      eliminatedAtRound: null
    });
  }

  removePlayer(socketId) {
    this.players.delete(socketId);
  }

  getCurrentQuestion() {
    return questions[this.currentQuestionIndex] || null;
  }

  startQuestion(io) {
    const q = this.getCurrentQuestion();
    if (!q) return;

    this.status = 'QUESTION_ACTIVE';
    this.timeRemaining = 30;
    this.questionStartTime = Date.now();

    for (const player of this.players.values()) {
      if (player.isAlive) {
        player.currentAnswer = null;
        player.responseTimeMs = null;
      }
    }

    io.emit('QUESTION_START', {
      round: this.currentQuestionIndex + 1,
      totalRounds: questions.length,
      quotaNextRound: q.quota,
      text: q.text,
      options: q.options,
      duration: 30
    });

    clearInterval(this.timerInterval);
    this.timerInterval = setInterval(() => {
      this.timeRemaining--;
      io.emit('TIMER_TICK', { timeRemaining: this.timeRemaining });

      if (this.timeRemaining <= 0) {
        clearInterval(this.timerInterval);
        this.processElimination(io);
      }
    }, 1000);
  }

  recordAnswer(socketId, answer) {
    if (this.status !== 'QUESTION_ACTIVE') {
      return { success: false, reason: "Thời gian trả lời chưa mở hoặc đã kết thúc." };
    }

    const player = this.players.get(socketId);
    if (!player || !player.isAlive) {
      return { success: false, reason: "Bạn đang ở Chế độ theo dõi." };
    }

    if (player.currentAnswer !== null) {
      return { success: false, reason: "Bạn đã nộp đáp án câu này rồi." };
    }

    const elapsedMs = Date.now() - this.questionStartTime;
    player.currentAnswer = answer;
    player.responseTimeMs = elapsedMs;

    return { success: true, responseTimeMs: elapsedMs };
  }

  processElimination(io) {
    this.status = 'EVALUATING';
    const currentQ = this.getCurrentQuestion();
    const roundNumber = this.currentQuestionIndex + 1;
    const correctPlayers = [];

    for (const player of this.players.values()) {
      if (!player.isAlive) continue;

      const isCorrect = player.currentAnswer === currentQ.correctAnswer;
      if (isCorrect && player.responseTimeMs !== null) {
        correctPlayers.push(player);
      } else {
        player.isAlive = false;
        player.eliminatedAtRound = roundNumber;
      }
    }

    // Xếp theo tốc độ trả lời (nhanh nhất lên đầu)
    correctPlayers.sort((a, b) => a.responseTimeMs - b.responseTimeMs);

    const quota = currentQ.quota;
    const survivors = correctPlayers.slice(0, quota);
    const cutOffPlayers = correctPlayers.slice(quota);

    cutOffPlayers.forEach(p => {
      p.isAlive = false;
      p.eliminatedAtRound = roundNumber;
    });

    const isLastRound = (this.currentQuestionIndex === questions.length - 1);

    // Gửi cập nhật riêng đến từng socket
    for (const [socketId, player] of this.players.entries()) {
      io.to(socketId).emit('PLAYER_STATUS_UPDATE', {
        isAlive: player.isAlive,
        eliminatedAtRound: player.eliminatedAtRound,
        yourAnswer: player.currentAnswer,
        yourTimeMs: player.responseTimeMs
      });
    }

    // Phát sóng kết quả vòng
    io.emit('ROUND_RESULT', {
      round: roundNumber,
      correctAnswer: currentQ.correctAnswer,
      quotaTarget: quota,
      survivorsCount: survivors.length,
      survivorsList: survivors.map(s => ({
        nickname: s.nickname,
        responseTimeMs: s.responseTimeMs
      })),
      isGameOver: isLastRound || survivors.length <= 1
    });

    if (isLastRound || survivors.length <= 1) {
      this.status = 'GAME_OVER';
    } else {
      this.currentQuestionIndex++;
    }
  }

  getLobbyInfo() {
    return {
      status: this.status,
      currentRound: this.currentQuestionIndex + 1,
      totalPlayers: this.players.size,
      players: Array.from(this.players.values()).map(p => ({
        nickname: p.nickname,
        isAlive: p.isAlive,
        eliminatedAtRound: p.eliminatedAtRound
      }))
    };
  }

  resetGame() {
    clearInterval(this.timerInterval);
    this.status = 'LOBBY';
    this.currentQuestionIndex = 0;
    this.questionStartTime = null;
    this.timeRemaining = 30;
    for (const player of this.players.values()) {
      player.isAlive = true;
      player.currentAnswer = null;
      player.responseTimeMs = null;
      player.eliminatedAtRound = null;
    }
  }
}

module.exports = new GameManager();
