const game = require('./gameState');

module.exports = (io) => {
  io.on('connection', (socket) => {
    socket.on('JOIN_GAME', ({ nickname }) => {
      game.addPlayer(socket.id, nickname);
      io.emit('LOBBY_UPDATE', game.getLobbyInfo());
    });

    socket.on('SUBMIT_ANSWER', ({ answer }) => {
      const res = game.recordAnswer(socket.id, answer);
      socket.emit('ANSWER_CONFIRMED', res);
    });

    socket.on('ADMIN_NEXT_QUESTION', () => {
      if (game.status === 'LOBBY' || game.status === 'EVALUATING') {
        game.startQuestion(io);
      }
    });

    socket.on('ADMIN_RESET_GAME', () => {
      game.resetGame();
      io.emit('GAME_RESET');
      io.emit('LOBBY_UPDATE', game.getLobbyInfo());
    });

    socket.on('REQUEST_LOBBY_DATA', () => {
      socket.emit('LOBBY_UPDATE', game.getLobbyInfo());
    });

    socket.on('disconnect', () => {
      game.removePlayer(socket.id);
      io.emit('LOBBY_UPDATE', game.getLobbyInfo());
    });
  });
};
